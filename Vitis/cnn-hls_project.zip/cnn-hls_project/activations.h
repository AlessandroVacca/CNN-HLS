//
// Created by federico on 28/02/22.
//

#ifndef CNN_XILINX_ACTIVATIONS_H
#define CNN_XILINX_ACTIVATIONS_H
// #include <cassert>
#include "types.h"
#include "params.h"
#include <hls_math.h>

fp24 relu(fp24 a);

void softmax(fp24 input[FC_ACT_SIZE], std::size_t size);

#endif //CNN_XILINX_ACTIVATIONS_H

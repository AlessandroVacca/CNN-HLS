//
// Created by federico on 28/02/22.
//
#ifndef CONV_WEIGHTS_H
#define CONV_WEIGHTS_H
#include "types.h"
#include "params.h"
/*
	BEFORE
	conv_bias[8]
	conv_weights[4][4][1][8]
*/
extern fp24 conv_bias[CONV_BIAS_SIZE];
extern fp24 conv_weights[CONV_KERNEL_SIZE][CONV_KERNEL_SIZE][CONV_CHANNELS][CONV_FILTERS];
#endif

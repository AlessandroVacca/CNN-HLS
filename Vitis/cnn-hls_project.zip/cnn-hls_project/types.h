#ifndef types_h
#define types_h
#include "ap_fixed.h"
typedef ap_fixed<24, 10, AP_RND> fp24;
#endif

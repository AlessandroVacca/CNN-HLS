#include "activations.h"

fp24 relu(fp24 a) {
    return a > (fp24) 0 ? a : (fp24) 0;
}

void softmax(fp24 input[FC_ACT_SIZE], std::size_t size) {

// assert(0 <= size <= sizeof(input) / sizeof(float));
    int i;
    fp24 m, sum, constant;

    m = input[0];

    for (i = 0; i < size; ++i) {
    	if (m < input[i]) {
    	   m = input[i];
        }
    }
    sum = 0.0;
    softmax_sum:
    for (i = 0; i < size; ++i) {
        sum += hls::exp((ap_fixed<24, 10>) (input[i] - m));
    }
    if (sum < 0.001)
    	sum = 0.001;
    fp24 temp = hls::log((ap_fixed<24, 10>) sum);
    constant = m + temp;
    softmax_exp:
    for (i = 0; i < size; ++i) {
        input[i] = hls::exp((ap_fixed<24, 10>) (input[i] - constant));
    }

}

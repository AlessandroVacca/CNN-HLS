#include <stdio.h>
#include <stdlib.h>
#include "layers.h"

int main()
{
	fp24 conv_out[A_SIZE * A_SIZE * A_CHANNELS];
	float conv_ref[A_SIZE][A_SIZE][A_CHANNELS];

	int i, j, k;
	hls::stream<fp24> out("output_stream");
	hls::stream<fp24> in("input_stream");
	float a;

	FILE* input = fopen("../../../../ref/input_image.txt","r");

	if (input == NULL) {
		printf("Cannot open ref/input_image.txt");
		exit(1);
	}
	// Move the image to the stream
	// 28x28 VS 32x32
	for (i = 0; i < IMAGE_SIZE * IMAGE_SIZE; i++) {
		fscanf(input,"%f,", &a);
		in << (fp24) a;
	}

	conv(out, in, conv_weights, conv_bias);

	for(i = 0 ; i < A_SIZE * A_SIZE * A_CHANNELS; i++)
		out >> conv_out[i];

	FILE* conv_content = fopen("../../../../ref/conv2d_out.txt","r");
		    if(conv_content == NULL)
		    {
		        printf("Couldn't open ../../../../ref/conv2d_out.txt");
		        exit(1);
		    }

	for(i = 0; i < A_SIZE; i++)
		for(j = 0; j < A_SIZE; j++)
			for(k = 0; k < A_CHANNELS; k++) {
				fscanf(conv_content,"%f,",&a);
				conv_ref[i][j][k] = (float) a;
			}

	int correct_values = 0, total_values = 0;

	printf("Checking CONV Layer ...\n");

	for(k = 0; k < A_CHANNELS; k++)
		for(i = 0; i < A_SIZE; i++)
			for(j = 0; j < A_SIZE; j++)
			{
				total_values++;
				if((float) conv_out[i* A_SIZE* A_CHANNELS + j*A_CHANNELS + k] - conv_ref[i][j][k] > eps || conv_ref[i][j][k] - (float) conv_out[i* A_SIZE* A_CHANNELS + j*A_CHANNELS + k] > eps)
				{
					if(correct_values + 1 == total_values)
						printf("Mismatch in CONV check\n");
				}
				else
					correct_values++;
			}
	printf("DONE: %d out of %d are correct\n\n", correct_values, total_values);

	return 0;
}

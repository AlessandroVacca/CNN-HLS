//
// Created by federico on 28/02/22.
//
#ifndef CNN_XILINX_LAYERS_H
#define CNN_XILINX_LAYERS_H

#include <vector>
#include "params.h"
#include "activations.h"
#include "types.h"
#include "hls_stream.h"
#include "conv_weights.h"
#include "fc_weights.h"

void fc(hls::stream<fp24> & out, hls::stream<fp24> & in, fp24 weight[FC_WEIGHTS_H][FC_WEIGHTS_W], fp24 bias[FC_BIAS_SIZE]);

void pool(hls::stream<fp24> & out, hls::stream<fp24> & in);

void conv(hls::stream<fp24> & out, hls::stream<fp24> & in, fp24 weight[CONV_KERNEL_SIZE][CONV_KERNEL_SIZE][CONV_CHANNELS][CONV_FILTERS], fp24 bias[CONV_BIAS_SIZE]);

void nnet(hls::stream<fp24> & in, hls::stream<fp24> & out);

#endif //CNN_XILINX_LAYERS_H

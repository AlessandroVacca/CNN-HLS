#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include "layers.h"

int main()
{

	fp24 input[FC_WEIGHTS_H];
	fp24 fc_out[FC_WEIGHTS_W];
	float fc_ref[FC_WEIGHTS_H];
	float a;

	int i;
	int correct_values = 0, total_values = 0;

	hls::stream<fp24> out;
	hls::stream<fp24> in;

	FILE* pool_out = fopen("../../../../ref/max_pooling2d_out.txt","r");
	if(pool_out == NULL)
	{
		printf("Couldn't open ../../../../ref/max_pooling2d_out.txt");
		exit(1);
	}

	FILE* fc_content_ref = fopen("../../../../ref/dense_out.txt","r");
	if(fc_content_ref == NULL)
	{
		printf("Couldn't open ../../../../ref/dense_out.txt");
		exit(1);
	}


    for (i = 0; i < FC_WEIGHTS_H; i++) {
    	fscanf(pool_out,"%f,", &a);
    	input[i] = (fp24) a;
    	// printf("%d\n", i);
    	// std::cout << input[i] << std::endl;
    }

    for (i = 0; i < FC_WEIGHTS_W; i++) {
    	fscanf(fc_content_ref,"%f,", &fc_ref[i]);
    	// std::cout << fc_ref[i] << std::endl;
    }
    for (i = 0; i < FC_WEIGHTS_H; i++) {
    	in << input[i];
    }

	fc(out, in, fc_weights, fc_bias);

    for (i = 0; i < FC_WEIGHTS_W; i++) {
    	out >> fc_out[i];
    }

    printf("Checking FC Layer ...\n");

    for(i = 0; i < FC_WEIGHTS_W; i++)
    {
    	total_values++;
    	printf("%f - %f\n", fc_out[i].to_float(), fc_ref[i]);

    	if(fc_out[i].to_float() - fc_ref[i] > eps || fc_ref[i] - fc_out[i].to_float() > eps)
    	{
    		if(correct_values + 1 == total_values)
    			printf("Mismatch in FC check\n");
    	}
    	else
    		correct_values++;
    	}
   	printf("DONE: %d out of %d are correct\n\n", correct_values, total_values);
	return 0;
}

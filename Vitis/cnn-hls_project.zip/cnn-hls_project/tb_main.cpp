#include <stdio.h>
#include <stdlib.h>
#include "layers.h"

int main()
{
		hls::stream<fp24> in("INPUT");
		hls::stream<fp24> out("OUTPUT");

		fp24 fc_out[FC_ACT_SIZE];
		float fc_ref[FC_ACT_SIZE];
		float a;

		int i, j, k;
		int correct_values, total_values;

		FILE* input = fopen("../../../../ref/input_image.txt","r");

		if (input == NULL) {
			printf("Cannot open ref/input_image.txt");
			exit(1);
		}
		// Move the image to the stream
		// 28x28 VS 32x32
		for (i = 0; i < IMAGE_SIZE * IMAGE_SIZE; i++) {
			fscanf(input,"%f,",&a);
			in << (fp24)a;
		}

		nnet(in, out);

		// Copy output for comparison
		for(i = 0; i < FC_ACT_SIZE; i++) {
			out >> fc_out[i];
		}

		FILE* fc_ref_fp = fopen("../../../../ref/dense_out.txt","r");

		if (fc_ref_fp == NULL) {
			printf("Couldn't open ref/dense_out.txt");
		    exit(1);
		}

		for (i = 0; i < FC_ACT_SIZE; i++) {
			fscanf(fc_ref_fp,"%f,", &fc_ref[i]);
		}

		correct_values = 0;
		total_values = 0;

		printf("\n\n\n\n");

		printf("Checking LAYERS ...\n");



		for(i = 0; i < FC_ACT_SIZE; i++)
		{
			total_values++;
			printf("%f - %f\n", (float) fc_out[i], fc_ref[i]);

			if(fc_out[i].to_float() - fc_ref[i] > eps || fc_ref[i] - fc_out[i].to_float() > eps)
			{
				if(correct_values + 1 == total_values)
					printf("Mismatch in check\n");
			}
				else
					correct_values++;

		}

		printf("DONE: %d out of %d are correct\n\n", correct_values, total_values);


		return 0;
}

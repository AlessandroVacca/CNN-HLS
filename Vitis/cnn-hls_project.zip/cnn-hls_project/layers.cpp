//
// Created by federico on 28/02/22.
//
#include "layers.h"

void fc(hls::stream<fp24> & out, hls::stream<fp24> & in, fp24 weight[FC_WEIGHTS_H][FC_WEIGHTS_W], fp24 bias[FC_BIAS_SIZE]) {
	fp24 read;
    fp24 output[FC_ACT_SIZE] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };

    fc_mul_weight_outer:
    for (int j = 0; j < FC_WEIGHTS_H; j++) {
    	// ALL LOOPS ARE PIPELINED
        // read = in[j];
    	in >> read;
        fc_mul_weight_inner:
        for (int i = 0; i < FC_WEIGHTS_W; i++) {
            output[i] += weight[j][i] * read;
        }
    }
    for (int i = 0; i < FC_WEIGHTS_W; i++) {
    	output[i] += bias[i];
    	// printf("output[%d] = %f\n", i, output[i].to_float());
    }
    /*
     * out[0] = -12.7418556; NO
     * out[1] = -12.3173447; NO
     * out[2] = -8.41031265; NO
     * out[3] = 3.29759002; OK
     * out[4] = -15.3710594; NO
     * out[5] = 7.6023984; OK
     * out[6] = -15.2298517; NO
     * out[7] = -9; NO
     * out[8] = -3; OK
     * out[9] = -5; OK
     * */
    softmax(output, FC_ACT_SIZE);
    fc_copy_tostream:
    for (int i = 0; i < FC_WEIGHTS_W; i++) {
        	out << output[i];
    }
}

void pool(hls::stream<fp24> & out, hls::stream<fp24> & in) {
    //int BUFFER_SIZE = (P_SIZE * P_CHANNELS);

    int i, j, k, l, m;
    fp24 read;

    fp24 pool_buff[P_BUFFER_SIZE];

    //hls::vector<fp24, P_BUFFER_SIZE> pool_buff;

    int z = 0;
    int out_index = 0;
    pool_maxsearch5:
    for (i = 0; i < P_SIZE; i++)
    	pool_maxsearch4:
        for (l = 0; l < P_KERNEL_SIZE; l++) {
        	pool_maxsearch3:
        	for (j = 0; j < P_SIZE; j++)
        		pool_maxsearch2:
        		for (m = 0; m < P_KERNEL_SIZE; m++)
        			pool_maxsearch1:
        			for (k = 0; k < P_CHANNELS; k++) {
                        // read = in[z];
                        in >> read;
                        z++;
                        if (l == 0 && m == 0)
                            pool_buff[j * P_CHANNELS + k] = read;

                        else
                            pool_buff[j * P_CHANNELS + k][0] =
                                    pool_buff[j * P_CHANNELS + k] > read ? pool_buff[j * P_CHANNELS + k] : read;


                        if (l == (P_KERNEL_SIZE - 1) && m == (P_KERNEL_SIZE - 1)) {
                            //out[out_index] = pool_buff[j * P_CHANNELS + k][0];
                            out << pool_buff[j * P_CHANNELS + k];
                            //out_index++;
                        }

                    }
        	pool_maxsearch0:
            for (int skip = P_SIZE * P_STRIDE; skip < A_SIZE; skip++)
            	pool_maxsearch0_inner:
            	for (int channel = 0; channel < P_CHANNELS; channel++) {
                    in >> read;
                    //z++;
                }
            //z = 0; // buffer reset
        }


    for(int skip_row = P_SIZE * P_STRIDE ; skip_row < A_SIZE; skip_row++)
        for(int skip_col = 0 ; skip_col < A_SIZE; skip_col++)
            for(int skip_channel = 0 ; skip_channel < A_CHANNELS; skip_channel++){
                in >> read;
                //z++;
            }
#ifndef __SYNTHESIS__
    pool_stream_empty:
    while (!in.empty())
    {
    	in >> read;
    }
#endif
}


void conv(hls::stream<fp24> & out, hls::stream<fp24> & in, fp24 weight[CONV_KERNEL_SIZE][CONV_KERNEL_SIZE][CONV_CHANNELS][CONV_FILTERS],
          fp24 bias[CONV_BIAS_SIZE]) {
    int i, j, k, filter, contor = 0;
    fp24 sum, placeholder;
    // these need to be initialized in the loops
    // int row_offset, col_offset, channel_offset;

    fp24 conv_buff[BUFFER_SIZE];
    // fp24 conv_buff[784];

    // std::vector<fp24> conv_buff;

    /// DEBUG
    int attempted_reads1 = 0, reads1 = 0;
    int attempted_reads2 = 0, reads2 = 0;
    int attempted_reads3 = 0, reads3 = 0;

    int z = 0;
    /*
     * Read the initial buffer
     * */
    conv_read_input:
    for (i = 0; i < BUFFER_SIZE; i++) {

        // placeholder = in[z];
        // placeholder << in;
        // conv_buff[z] << in;
        in >> conv_buff[z];
        z++;
        // conv_buff.push_back(placeholder);
        reads1++;
    }

    int out_index = 0;
        conv_label5:
        for (i = 0; i < (IMAGE_SIZE - CONV_KERNEL_SIZE + 1); i += CONV_STRIDE) {
            conv_label4:
            for (j = 0; j < (IMAGE_SIZE - CONV_KERNEL_SIZE + 1); j += CONV_STRIDE) {
                conv_label3:
                for (filter = 0; filter < CONV_FILTERS; filter++) {

                    sum = 0;

                    conv_label2:
                    for (int row_offset = 0; row_offset < CONV_KERNEL_SIZE; row_offset++)
                        conv_label1:
                        for (int col_offset = 0; col_offset < CONV_KERNEL_SIZE; col_offset++)
                            conv_label0:
                            for (int channel_offset = 0; channel_offset < CONV_CHANNELS; channel_offset++)
                                sum += conv_buff[row_offset * IMAGE_SIZE * IMAGE_CHANNELS +
                                                 col_offset * IMAGE_CHANNELS +
                                                 channel_offset
                                                 + i*(IMAGE_SIZE) + j] *
                                       weight[row_offset][col_offset][channel_offset][filter];
                    // out[out_index] = relu(sum + bias[filter]);
                    out << relu(sum + bias[filter]);
                }
//
//            if ((j + CONV_STRIDE < (IMAGE_SIZE - CONV_KERNEL_SIZE + 1)))
//                for (int p = 0; p < IMAGE_CHANNELS; p++) {
//                    attempted_reads3++;
////            if(in.empty() == 1)
////            {
////#ifndef __SYNTHESIS__
////                printf("\nInput stream is empty at \"Next element state\"");
////#endif
////            }
////            else
////            {
//                    reads3++;
//                    placeholder = in[z];
//                    z++;
//                    conv_buff.push_back(placeholder);
//                }
////        }
//        else
//            if ((i + CONV_STRIDE < (IMAGE_SIZE - CONV_KERNEL_SIZE + 1)) &&
//                (j + CONV_STRIDE >= (IMAGE_SIZE - CONV_KERNEL_SIZE + 1)))
//                for (int p = 0; p < CONV_KERNEL_SIZE * IMAGE_CHANNELS; p++) {
//                    attempted_reads2++;
////            if(in.empty() == 1)
////            {
////#ifndef __SYNTHESIS__
////                printf("\nInput stream is empty at \"Endline\"");
////#endif
////            }
////            else
////            {
//                    reads2++;
//                    placeholder = in[z];
//                    z++;
//                    conv_buff.push_back(placeholder);
////            }
//                }

            };

    }
//#ifndef __SYNTHESIS__
//    printf("\n===========");
//    printf("\nStatistics:");
//    printf("\n===========");
//
//    printf("\nInitial buffer attempted to read %d and succeeded %d", attempted_reads1, reads1);
//    printf("\nEndline buffer attempted to read %d and succeeded %d", attempted_reads2, reads2);
//    printf("\nNextelm buffer attempted to read %d and succeeded %d", attempted_reads3, reads3);
//#endif
}

void nnet(hls::stream<fp24> & in, hls::stream<fp24> & out) {
	hls::stream<fp24> conv_out("conv_out");
	hls::stream<fp24> pool_out("pool_out");

	conv(conv_out, in, conv_weights, conv_bias);
	pool(pool_out, conv_out);
	fc(out, pool_out, fc_weights, fc_bias);
}


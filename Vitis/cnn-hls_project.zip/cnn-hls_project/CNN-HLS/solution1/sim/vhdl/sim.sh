#!/bin/sh
# ==============================================================
# Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2021.2 (64-bit)
# Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
# ==============================================================
# The next line restarts using autoesl tclsh \
    exec /tools/Xilinx/Vitis_HLS/2021.2/bin/vitis_hls run_sim.tcl

// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2021.2 (64-bit)
// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_weights_V_2_1_0_ROM_AUibs_H__
#define __nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_weights_V_2_1_0_ROM_AUibs_H__


#include <systemc>
using namespace sc_core;
using namespace sc_dt;




#include <iostream>
#include <fstream>

struct nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_weights_V_2_1_0_ROM_AUibs_ram : public sc_core::sc_module {

  static const unsigned DataWidth = 15;
  static const unsigned AddressRange = 32;
  static const unsigned AddressWidth = 5;

//latency = 1
//input_reg = 1
//output_reg = 0
sc_core::sc_in <sc_lv<AddressWidth> > address0;
sc_core::sc_in <sc_logic> ce0;
sc_core::sc_out <sc_lv<DataWidth> > q0;
sc_core::sc_in<sc_logic> reset;
sc_core::sc_in<bool> clk;


sc_lv<DataWidth> ram[AddressRange];


   SC_CTOR(nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_weights_V_2_1_0_ROM_AUibs_ram) {
        ram[0] = "0b001010001011111";
        ram[1] = "0b111001100010011";
        ram[2] = "0b000101001100100";
        ram[3] = "0b001011101100010";
        ram[4] = "0b111111110111110";
        ram[5] = "0b110010111000110";
        ram[6] = "0b001000000001111";
        ram[7] = "0b001101100100110";
        ram[8] = "0b110010010000101";
        ram[9] = "0b000011100100110";
        ram[10] = "0b101100111011110";
        ram[11] = "0b001101100101100";
        ram[12] = "0b000100101101001";
        ram[13] = "0b111110111000001";
        ram[14] = "0b111000110001111";
        ram[15] = "0b101000111100001";
        ram[16] = "0b001011011010101";
        ram[17] = "0b001101100001010";
        ram[18] = "0b111110011000101";
        ram[19] = "0b101010110010110";
        ram[20] = "0b111001011001110";
        ram[21] = "0b000001101000000";
        ram[22] = "0b000011100010010";
        ram[23] = "0b111010100111010";
        ram[24] = "0b000001111001001";
        ram[25] = "0b000101101001010";
        ram[26] = "0b000000100101010";
        ram[27] = "0b100010110111011";
        ram[28] = "0b001100000110100";
        ram[29] = "0b101100001001001";
        ram[30] = "0b110110010111100";
        ram[31] = "0b000111101101110";


SC_METHOD(prc_write_0);
  sensitive<<clk.pos();
   }


void prc_write_0()
{
    if (ce0.read() == sc_dt::Log_1) 
    {
            if(address0.read().is_01() && address0.read().to_uint()<AddressRange)
              q0 = ram[address0.read().to_uint()];
            else
              q0 = sc_lv<DataWidth>();
    }
}


}; //endmodule


SC_MODULE(nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_weights_V_2_1_0_ROM_AUibs) {


static const unsigned DataWidth = 15;
static const unsigned AddressRange = 32;
static const unsigned AddressWidth = 5;

sc_core::sc_in <sc_lv<AddressWidth> > address0;
sc_core::sc_in<sc_logic> ce0;
sc_core::sc_out <sc_lv<DataWidth> > q0;
sc_core::sc_in<sc_logic> reset;
sc_core::sc_in<bool> clk;


nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_weights_V_2_1_0_ROM_AUibs_ram* meminst;


SC_CTOR(nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_weights_V_2_1_0_ROM_AUibs) {
meminst = new nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_weights_V_2_1_0_ROM_AUibs_ram("nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_weights_V_2_1_0_ROM_AUibs_ram");
meminst->address0(address0);
meminst->ce0(ce0);
meminst->q0(q0);

meminst->reset(reset);
meminst->clk(clk);
}
~nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_weights_V_2_1_0_ROM_AUibs() {
    delete meminst;
}


};//endmodule
#endif

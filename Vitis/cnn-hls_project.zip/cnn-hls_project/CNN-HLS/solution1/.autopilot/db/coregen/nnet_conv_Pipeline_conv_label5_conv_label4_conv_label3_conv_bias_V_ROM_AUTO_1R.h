// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2021.2 (64-bit)
// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_bias_V_ROM_AUTO_1R_H__
#define __nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_bias_V_ROM_AUTO_1R_H__


#include <systemc>
using namespace sc_core;
using namespace sc_dt;




#include <iostream>
#include <fstream>

struct nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_bias_V_ROM_AUTO_1R_ram : public sc_core::sc_module {

  static const unsigned DataWidth = 14;
  static const unsigned AddressRange = 32;
  static const unsigned AddressWidth = 5;

//latency = 1
//input_reg = 1
//output_reg = 0
sc_core::sc_in <sc_lv<AddressWidth> > address0;
sc_core::sc_in <sc_logic> ce0;
sc_core::sc_out <sc_lv<DataWidth> > q0;
sc_core::sc_in<sc_logic> reset;
sc_core::sc_in<bool> clk;


sc_lv<DataWidth> ram[AddressRange];


   SC_CTOR(nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_bias_V_ROM_AUTO_1R_ram) {
        ram[0] = "0b11110101000011";
        ram[1] = "0b11111110101110";
        ram[2] = "0b10011101100000";
        ram[3] = "0b11111011001001";
        ram[4] = "0b11111011000111";
        ram[5] = "0b11001001101010";
        ram[6] = "0b11011111010101";
        ram[7] = "0b00011000110000";
        ram[8] = "0b11101000100111";
        ram[9] = "0b11010011101000";
        ram[10] = "0b11111011111100";
        ram[11] = "0b11111110011011";
        ram[12] = "0b00000100000110";
        ram[13] = "0b11000111010001";
        ram[14] = "0b11100101110111";
        ram[15] = "0b11010010110001";
        ram[16] = "0b11100111000100";
        ram[17] = "0b10011000000001";
        ram[18] = "0b00010010010011";
        ram[19] = "0b00001101010011";
        ram[20] = "0b11101101001001";
        ram[21] = "0b11010001110111";
        ram[22] = "0b11100110001010";
        ram[23] = "0b10110001101011";
        ram[24] = "0b10111101100011";
        ram[25] = "0b11001010010011";
        ram[26] = "0b11000111000100";
        ram[27] = "0b11111101111010";
        ram[28] = "0b11101101010101";
        ram[29] = "0b11110001010110";
        ram[30] = "0b11101011111011";
        ram[31] = "0b11011101001010";


SC_METHOD(prc_write_0);
  sensitive<<clk.pos();
   }


void prc_write_0()
{
    if (ce0.read() == sc_dt::Log_1) 
    {
            if(address0.read().is_01() && address0.read().to_uint()<AddressRange)
              q0 = ram[address0.read().to_uint()];
            else
              q0 = sc_lv<DataWidth>();
    }
}


}; //endmodule


SC_MODULE(nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_bias_V_ROM_AUTO_1R) {


static const unsigned DataWidth = 14;
static const unsigned AddressRange = 32;
static const unsigned AddressWidth = 5;

sc_core::sc_in <sc_lv<AddressWidth> > address0;
sc_core::sc_in<sc_logic> ce0;
sc_core::sc_out <sc_lv<DataWidth> > q0;
sc_core::sc_in<sc_logic> reset;
sc_core::sc_in<bool> clk;


nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_bias_V_ROM_AUTO_1R_ram* meminst;


SC_CTOR(nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_bias_V_ROM_AUTO_1R) {
meminst = new nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_bias_V_ROM_AUTO_1R_ram("nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_bias_V_ROM_AUTO_1R_ram");
meminst->address0(address0);
meminst->ce0(ce0);
meminst->q0(q0);

meminst->reset(reset);
meminst->clk(clk);
}
~nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_bias_V_ROM_AUTO_1R() {
    delete meminst;
}


};//endmodule
#endif

// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2021.2 (64-bit)
// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_weights_V_1_2_0_ROM_AUg8j_H__
#define __nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_weights_V_1_2_0_ROM_AUg8j_H__


#include <systemc>
using namespace sc_core;
using namespace sc_dt;




#include <iostream>
#include <fstream>

struct nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_weights_V_1_2_0_ROM_AUg8j_ram : public sc_core::sc_module {

  static const unsigned DataWidth = 15;
  static const unsigned AddressRange = 32;
  static const unsigned AddressWidth = 5;

//latency = 1
//input_reg = 1
//output_reg = 0
sc_core::sc_in <sc_lv<AddressWidth> > address0;
sc_core::sc_in <sc_logic> ce0;
sc_core::sc_out <sc_lv<DataWidth> > q0;
sc_core::sc_in<sc_logic> reset;
sc_core::sc_in<bool> clk;


sc_lv<DataWidth> ram[AddressRange];


   SC_CTOR(nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_weights_V_1_2_0_ROM_AUg8j_ram) {
        ram[0] = "0b001000011000011";
        ram[1] = "0b001011101100100";
        ram[2] = "0b111101101011010";
        ram[3] = "0b111010100000111";
        ram[4] = "0b001011011100001";
        ram[5] = "0b110000010100100";
        ram[6] = "0b000100101011001";
        ram[7] = "0b100001110111011";
        ram[8] = "0b001000001111000";
        ram[9] = "0b111110110100011";
        ram[10] = "0b000000111110010";
        ram[11] = "0b001101100110010";
        ram[12] = "0b000101010011001";
        ram[13] = "0b111001001110001";
        ram[14] = "0b000011101001101";
        ram[15] = "0b001000011000111";
        ram[16] = "0b101000011110010";
        ram[17] = "0b101111011011001";
        ram[18] = "0b001100000011000";
        ram[19] = "0b000001100111110";
        ram[20] = "0b000010110011001";
        ram[21] = "0b001010100101001";
        ram[22] = "0b000111101011001";
        ram[23] = "0b000110010010010";
        ram[24] = "0b000101000010110";
        ram[25] = "0b001010001101001";
        ram[26] = "0b001000100111001";
        ram[27] = "0b100100111001000";
        ram[28] = "0b110100000111010";
        ram[29] = "0b001111000010100";
        ram[30] = "0b101111010101010";
        ram[31] = "0b111111101111001";


SC_METHOD(prc_write_0);
  sensitive<<clk.pos();
   }


void prc_write_0()
{
    if (ce0.read() == sc_dt::Log_1) 
    {
            if(address0.read().is_01() && address0.read().to_uint()<AddressRange)
              q0 = ram[address0.read().to_uint()];
            else
              q0 = sc_lv<DataWidth>();
    }
}


}; //endmodule


SC_MODULE(nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_weights_V_1_2_0_ROM_AUg8j) {


static const unsigned DataWidth = 15;
static const unsigned AddressRange = 32;
static const unsigned AddressWidth = 5;

sc_core::sc_in <sc_lv<AddressWidth> > address0;
sc_core::sc_in<sc_logic> ce0;
sc_core::sc_out <sc_lv<DataWidth> > q0;
sc_core::sc_in<sc_logic> reset;
sc_core::sc_in<bool> clk;


nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_weights_V_1_2_0_ROM_AUg8j_ram* meminst;


SC_CTOR(nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_weights_V_1_2_0_ROM_AUg8j) {
meminst = new nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_weights_V_1_2_0_ROM_AUg8j_ram("nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_weights_V_1_2_0_ROM_AUg8j_ram");
meminst->address0(address0);
meminst->ce0(ce0);
meminst->q0(q0);

meminst->reset(reset);
meminst->clk(clk);
}
~nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_weights_V_1_2_0_ROM_AUg8j() {
    delete meminst;
}


};//endmodule
#endif

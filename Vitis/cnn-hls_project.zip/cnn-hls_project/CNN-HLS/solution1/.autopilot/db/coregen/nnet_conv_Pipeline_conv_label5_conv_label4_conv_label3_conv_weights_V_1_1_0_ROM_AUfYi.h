// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2021.2 (64-bit)
// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_weights_V_1_1_0_ROM_AUfYi_H__
#define __nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_weights_V_1_1_0_ROM_AUfYi_H__


#include <systemc>
using namespace sc_core;
using namespace sc_dt;




#include <iostream>
#include <fstream>

struct nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_weights_V_1_1_0_ROM_AUfYi_ram : public sc_core::sc_module {

  static const unsigned DataWidth = 15;
  static const unsigned AddressRange = 32;
  static const unsigned AddressWidth = 5;

//latency = 1
//input_reg = 1
//output_reg = 0
sc_core::sc_in <sc_lv<AddressWidth> > address0;
sc_core::sc_in <sc_logic> ce0;
sc_core::sc_out <sc_lv<DataWidth> > q0;
sc_core::sc_in<sc_logic> reset;
sc_core::sc_in<bool> clk;


sc_lv<DataWidth> ram[AddressRange];


   SC_CTOR(nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_weights_V_1_1_0_ROM_AUfYi_ram) {
        ram[0] = "0b000111011100001";
        ram[1] = "0b010001110000101";
        ram[2] = "0b000011100010011";
        ram[3] = "0b000100111111011";
        ram[4] = "0b000110111000111";
        ram[5] = "0b000000000100010";
        ram[6] = "0b111110101110010";
        ram[7] = "0b000100101000010";
        ram[8] = "0b101000111101000";
        ram[9] = "0b000000000001111";
        ram[10] = "0b001011100000001";
        ram[11] = "0b111100111001111";
        ram[12] = "0b001110100010011";
        ram[13] = "0b000101110010111";
        ram[14] = "0b001000110001110";
        ram[15] = "0b001000101001011";
        ram[16] = "0b000101101100111";
        ram[17] = "0b000101100001000";
        ram[18] = "0b001000100000100";
        ram[19] = "0b001111000111101";
        ram[20] = "0b001000110000111";
        ram[21] = "0b000101001011000";
        ram[22] = "0b001000100111011";
        ram[23] = "0b000000101100010";
        ram[24] = "0b001101000101111";
        ram[25] = "0b000011100000001";
        ram[26] = "0b111111011000100";
        ram[27] = "0b000110001110011";
        ram[28] = "0b000001110101010";
        ram[29] = "0b100010010000001";
        ram[30] = "0b111101000100100";
        ram[31] = "0b111111101001100";


SC_METHOD(prc_write_0);
  sensitive<<clk.pos();
   }


void prc_write_0()
{
    if (ce0.read() == sc_dt::Log_1) 
    {
            if(address0.read().is_01() && address0.read().to_uint()<AddressRange)
              q0 = ram[address0.read().to_uint()];
            else
              q0 = sc_lv<DataWidth>();
    }
}


}; //endmodule


SC_MODULE(nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_weights_V_1_1_0_ROM_AUfYi) {


static const unsigned DataWidth = 15;
static const unsigned AddressRange = 32;
static const unsigned AddressWidth = 5;

sc_core::sc_in <sc_lv<AddressWidth> > address0;
sc_core::sc_in<sc_logic> ce0;
sc_core::sc_out <sc_lv<DataWidth> > q0;
sc_core::sc_in<sc_logic> reset;
sc_core::sc_in<bool> clk;


nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_weights_V_1_1_0_ROM_AUfYi_ram* meminst;


SC_CTOR(nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_weights_V_1_1_0_ROM_AUfYi) {
meminst = new nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_weights_V_1_1_0_ROM_AUfYi_ram("nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_weights_V_1_1_0_ROM_AUfYi_ram");
meminst->address0(address0);
meminst->ce0(ce0);
meminst->q0(q0);

meminst->reset(reset);
meminst->clk(clk);
}
~nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_weights_V_1_1_0_ROM_AUfYi() {
    delete meminst;
}


};//endmodule
#endif

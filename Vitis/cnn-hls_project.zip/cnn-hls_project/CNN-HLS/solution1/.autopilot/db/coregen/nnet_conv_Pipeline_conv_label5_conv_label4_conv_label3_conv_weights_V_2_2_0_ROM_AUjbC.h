// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2021.2 (64-bit)
// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_weights_V_2_2_0_ROM_AUjbC_H__
#define __nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_weights_V_2_2_0_ROM_AUjbC_H__


#include <systemc>
using namespace sc_core;
using namespace sc_dt;




#include <iostream>
#include <fstream>

struct nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_weights_V_2_2_0_ROM_AUjbC_ram : public sc_core::sc_module {

  static const unsigned DataWidth = 16;
  static const unsigned AddressRange = 32;
  static const unsigned AddressWidth = 5;

//latency = 1
//input_reg = 1
//output_reg = 0
sc_core::sc_in <sc_lv<AddressWidth> > address0;
sc_core::sc_in <sc_logic> ce0;
sc_core::sc_out <sc_lv<DataWidth> > q0;
sc_core::sc_in<sc_logic> reset;
sc_core::sc_in<bool> clk;


sc_lv<DataWidth> ram[AddressRange];


   SC_CTOR(nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_weights_V_2_2_0_ROM_AUjbC_ram) {
        ram[0] = "0b1110110110101000";
        ram[1] = "0b1110110011000100";
        ram[2] = "0b0001001100000111";
        ram[3] = "0b0000011110010111";
        ram[4] = "0b1111001010010011";
        ram[5] = "0b1101111000111010";
        ram[6] = "0b0000000000000010";
        ram[7] = "0b1110111111110110";
        ram[8] = "0b0000111100111100";
        ram[9] = "0b0000110111011110";
        ram[10] = "0b1101010010000001";
        ram[11] = "0b0001010001001000";
        ram[12] = "0b1111110001111111";
        ram[13] = "0b0001000000010111";
        ram[14] = "0b0000100000010001";
        ram[15] = "0b0000000100011001";
        ram[16] = "0b1110101110011100";
        ram[17] = "0b0000100000100001";
        ram[18] = "0b0001001000101100";
        ram[19] = "0b1011000111000011";
        ram[20] = "0b0000010111111111";
        ram[21] = "0b0001001100011110";
        ram[22] = "0b1110101010110100";
        ram[23] = "0b0001011000101010";
        ram[24] = "0b0000110100100000";
        ram[25] = "0b0000001101110011";
        ram[26] = "0b0000111000111010";
        ram[27] = "0b1101001100100010";
        ram[28] = "0b0000100101100100";
        ram[29] = "0b0000100011001001";
        ram[30] = "0b1111010010101101";
        ram[31] = "0b1111000100101111";


SC_METHOD(prc_write_0);
  sensitive<<clk.pos();
   }


void prc_write_0()
{
    if (ce0.read() == sc_dt::Log_1) 
    {
            if(address0.read().is_01() && address0.read().to_uint()<AddressRange)
              q0 = ram[address0.read().to_uint()];
            else
              q0 = sc_lv<DataWidth>();
    }
}


}; //endmodule


SC_MODULE(nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_weights_V_2_2_0_ROM_AUjbC) {


static const unsigned DataWidth = 16;
static const unsigned AddressRange = 32;
static const unsigned AddressWidth = 5;

sc_core::sc_in <sc_lv<AddressWidth> > address0;
sc_core::sc_in<sc_logic> ce0;
sc_core::sc_out <sc_lv<DataWidth> > q0;
sc_core::sc_in<sc_logic> reset;
sc_core::sc_in<bool> clk;


nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_weights_V_2_2_0_ROM_AUjbC_ram* meminst;


SC_CTOR(nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_weights_V_2_2_0_ROM_AUjbC) {
meminst = new nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_weights_V_2_2_0_ROM_AUjbC_ram("nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_weights_V_2_2_0_ROM_AUjbC_ram");
meminst->address0(address0);
meminst->ce0(ce0);
meminst->q0(q0);

meminst->reset(reset);
meminst->clk(clk);
}
~nnet_conv_Pipeline_conv_label5_conv_label4_conv_label3_conv_weights_V_2_2_0_ROM_AUjbC() {
    delete meminst;
}


};//endmodule
#endif
